/*function showMessage() {
  alert( 'Всем привет!' );
}

showMessage();
showMessage();*/
/*function calc(num, exp){
  let res=1;
  for(let i=1; i<=exp; i++){
    res=res*num;
  }
  return res;
}
  const result=calc(2,10);
  console.log(result);*/
  // Плошадь прямоугольника:
  /*const area=(a,b) =>{
    if((a>0)&&(b>0)){
    return a*b;
  }else{
    return null;
  }
}
   const result=area(5,4);
   console.log(result);*/ //умножение двух чисел
/*   let userName = 'Oleg';

 function showMessage() {
   let message = 'Привет, ' + userName;
   alert(message);
 }

 showMessage(); */  // Задание 1
//--------------------------------------------------------------------------------------------
/* let userName=prompt('Как Вас зовут?:');
    function showMessage() {
       let message = 'Привет, ' + userName;
   alert(message);
 }
    showMessage();*/  //Задание 2
//--------------------------------------------------------------------------------------------
/*  function min( a,b ) {
      if( a < b ) {
         return(a);
      } else if( b < a ) {
         return(b);
      } else {
         return( 'Ты серьёзно? Они же равны....');
      }
    }
   let res=min(5,4);
             alert(res);*/  // Задание 3
//--------------------------------------------------------------------------------------------
    function Calculate()
    {
var a = eval( document.forms.figure.a.value); //ввод переменных a,b,c с формы
var b = eval( document.forms.figure.b.value);
var c = eval( document.forms.figure.c.value);
var d = b * b - 4 * a * c;
document.forms.figure.dis.value = d;

//метод .toFixed(n) округляет с точностью до n знаков

if( d < 0) //вывод корней в зависимости от дискриминанта
{
var str = "";
str += ((-b)/(2*a)).toFixed(4);
str += " + i * ";
str += (Math.sqrt(-d)/(2*a)).toFixed(4);
document.forms.figure.x1.value = str;

str = "";
str += ((-b)/(2*a)).toFixed(4);
str += " - i * ";
str += (Math.sqrt(-d)/(2*a)).toFixed(4);
document.forms.figure.x2.value = str;
}
else
{
document.forms.figure.x1.value = (-b+Math.sqrt(d))/(2*a).toFixed(4);
document.forms.figure.x2.value = (-b-Math.sqrt(d))/(2*a).toFixed(4);
}

//Задание 4, 5?

}  //Задание 4
