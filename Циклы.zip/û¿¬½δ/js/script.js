/*let sum=0;
 let number=1;
 while (number <=100) {
  sum=sum+number;
    number++;
 }
  console.log(sum);*/



/*let number=1;
while (number <=40) {
  alert(number);
  number++;
}*/
  /*let number=1;
   do {
     alert(number);
     number++;
   } while (number<=40);*/

  /* for (var i = 1; i <=40; i++) {
    alert(i);
  }*/ // задание 1

 /* let number=0;
  while (number <=40) {
    alert(number);
  } */   //Задание 2

    do {
       var number=+prompt('Введите число, больше 5 ? ');
       if (number>5) {
         alert('Поздравляю все правильно!');
       }
         else  {
           alert('Повторите ввод числа');
         }
         if (number==false){
          alert('Пока)))');
         }
     } while (number <=5 && number);   //Задание 3

   /* for ( let i=8; i<=20; i++){
      if(i%2==0)
      alert(i);
    }*/ //Задание 4
    

    /* for (let i = 1; i <=7; i++){
    if(i % 2==0 || i==5) continue;
    alert(i);}*/ //Задание 5

  
  